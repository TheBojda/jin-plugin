<?php
	
	require_once "lib/jin_plugin/Plugin.class.php";
		
	class plugin3 implements Plugin {
		
		public function init($pluginManager) {
			echo "updated plugin3 initialized!<br/>";
		}
		
	}
	
?>